public class D {
    private C c;
    private String name;

    public D(String name) {
        this.name = name;
    }

    public void setC(C c) {
        this.c = c;
    }

    public C getC() {
        return c;
    }

    public String getName() {
        return name;
    }
}